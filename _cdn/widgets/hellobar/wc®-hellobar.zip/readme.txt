GUIA DE INSTALAÇÃO: Ative o WC CUSTOM e...


ARQUIVO					LINHA			CÓDIGO

_app/Config.inc.php			51			define('DB_HELLO', 'ws_hellobar'); //Tabela da wc hello bar
_app/Config/Config.inc.php		81			define('LEVEL_WC_HELLO', 6);



INSTALANDO FOLDER:
/admin/_siswc				hello
/admin/_ajax				Custom.ajax.php
					

MENU:	<?php if ($Admin['user_level'] >= LEVEL_WC_HELLO): ?><li class="dashboard_nav_menu_li <?= strstr($getViewInput, 'hello/home') ? 'dashboard_nav_menu_active' : ''; ?>"><a class="icon-bullhorn" title="WC® Hellobar" href="dashboard.php?wc=hello/home">WC® Hellobar</a></li><?php endif; ?>


DUMP NO SQL wc_hellobar.sql

ADICIONE A PASTA HELLOBAR na pasta de widgets, e em seu arquivo sctips.js do tema, chame a seguinte função:

//INSTALA A HELLOBAR
    $.getScript(BASE + "/_cdn/widgets/hellobar/hellobar.wc.js", function () {
        $("head").append("<link rel='stylesheet' href='" + BASE + "/_cdn/widgets/hellobar/hellobar.wc.css'/>");
    });
