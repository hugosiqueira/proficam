DROP TABLE IF EXISTS `ws_hellobar`;

CREATE TABLE `ws_hellobar` (
  `user_id` int(11) unsigned NOT NULL,
  `hello_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hello_title` varchar(255) DEFAULT NULL,
  `hello_image` varchar(244) DEFAULT NULL,
  `hello_cta` varchar(70) DEFAULT NULL,
  `hello_link` varchar(255) DEFAULT NULL,
  `hello_color` varchar(50) DEFAULT NULL,
  `hello_position` varchar(70) DEFAULT NULL,
  `hello_rule` varchar(255) DEFAULT NULL,
  `hello_date` timestamp NULL DEFAULT NULL,
  `hello_start` timestamp NULL DEFAULT NULL,
  `hello_end` timestamp NULL DEFAULT NULL,
  `hello_views` int(11) DEFAULT NULL,
  `hello_clicks` int(11) DEFAULT NULL,
  `hello_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`hello_id`),
  KEY `wc_hello_user` (`user_id`),
  CONSTRAINT `wc_hello_user` FOREIGN KEY (`user_id`) REFERENCES `ws_users` (`user_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;