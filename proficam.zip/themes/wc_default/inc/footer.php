<footer class="main_footer">
    <p>Orgulhosamente desenvolvido com Work Control!</p>
    <p>&COPY; 2016 - Curso Work Series - Projeto e Produção</p>
</footer>
