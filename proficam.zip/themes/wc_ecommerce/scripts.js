$(function () {
    $('.main_nav_mobile_menu').click(function () {
        $('.main_nav ul').slideToggle();
    });
});