<div class="container" style="background: #fff;">
    <?php require '_cdn/widgets/imobi/filter.wc.php'; ?>
</div>
<div class="content">
    <header class="section_header">
        <h1>Confira resultados de sua busca:</h1>
        <p>Veja abaixo os imóveis que atendem sua necessidade!</p>
    </header>
    <?php require '_cdn/widgets/imobi/list.wc.php'; ?>
    <div class="clear"></div>
</div>
